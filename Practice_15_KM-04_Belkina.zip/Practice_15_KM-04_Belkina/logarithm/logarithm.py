'''
Logarithm module
'''

import math

def log(a, b):
    return math.log(b, a)

def ln(b):
    return math.log1p(b)

def lg(b):
    return math.log10(b)