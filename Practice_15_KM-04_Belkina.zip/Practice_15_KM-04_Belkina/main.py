import factorial.factorial
import logarithm.logarithm
import exp_root.exponentiation
import exp_root.root

def intpoz_number(n):
    try:
        if int(n)>0:
            return True
    except ValueError:
        return False

def number(n):
    try:
        float(n)
        return True
    except ValueError:
        return False

def poz_number(n):
    try:
        if float(n)>0:
            return True
    except ValueError:
        return False


def main():
    while True:
        x=input("\nEnter 1 if you would like to calculate factorial;"
                "\nEnter 2 if you would like to calculate logarithm;"
                "\nEnter 3 if you would like to calculate root;"
                "\nEnter 4 if you would like to calculate exponential;"
                "\nEnter !! if you would like to exit: ")
        if x=="1":
            n=input("Enter natural number: ")
            if intpoz_number(n):
                print(factorial.factorial.fact(int(n)))
            else:
                print("Factorial is not exist")
        elif x=="2":
            m = input("\nEnter 1 if you would like to calculate log();"
                      "\nEnter 2 if you would like to calculate lg();"
                      "\nEnter 3 if you would like to calculate ln(): ")
            if m=="1":
                a=input("Enter the base: ")
                b=input("Enter the number: ")
                if poz_number(a) and poz_number(b) and a!="1":
                    print(logarithm.logarithm.log(float(a), float(b)))
                else:
                    print("Logarithm is not exist")
            elif m=="2":
                b = input("Enter the number: ")
                if poz_number(b):
                    print(logarithm.logarithm.lg(float(b)))
                else:
                    print("Logarithm is not exist")
            elif m=="3":
                b = input("Enter the number: ")
                if poz_number(b):
                    print(logarithm.logarithm.ln(float(b)))
                else:
                    print("Logarithm is not exist")
            else:
                print("Entered number is not found")
        elif x=="3":
            o=input("\nEnter 1 if you would like to calculate square root;"
                      "\nEnter 2 if you would like to calculate cubic root: ")
            if o=="1":
                b = input("Enter the number: ")
                if poz_number(b):
                    print(exp_root.root.root2(float(b)))
                else:
                    print("Square root is not exist")
            elif o=="2":
                b = input("Enter the number: ")
                if number(b):
                    print(exp_root.root.root3(float(b)))
                else:
                    print("Cubic root is not exist")
            else:
                print("Entered number is not found")
        elif x=="4":
            o = input("\nEnter 1 if you would like to calculate square number;"
                      "\nEnter 2 if you would like to calculate cubic number: ")
            if o == "1":
                b = input("Enter the number: ")
                if number(b):
                    print(exp_root.exponentiation.exp2(float(b)))
                else:
                    print("Square number is not exist")
            elif o == "2":
                b = input("Enter the number: ")
                if number(b):
                    print(exp_root.exponentiation.exp3(float(b)))
                else:
                    print("Cubic number is not exist")
            else:
                print("Entered number is not found")
        elif x=="!!":
            print("The end...")
            break
        else:
            print("Incorrect value")


if __name__ == '__main__':
    main()
