'''
Root module
'''

def root2(n):
    return n**0.5

def root3(n):
    return n**(1/3)